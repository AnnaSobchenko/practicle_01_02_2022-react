export const getIsLoading=(state)=>state.transactions.isLoading;

export const getTransactions=(state)=>state.transactions;