import { Form } from "react-bootstrap";
import styled from "styled-components";

export const SelectTranstypeStyled=styled(Form.Select)`
width: 130px;
margin: 0 auto;
margin-bottom: 20px;
`